---
name: Feature request
about: Suggest a new feature for Termux application

---

<!--
IMPORTANT:

1. Support of Android 5.x - 6.x is finished.
2. Fill the template AFTER comments.
-->

**Feature description**
<!--
Describe the feature and why you want it.
-->

**Reference implementation**

Does another app/terminal emulator have this feature?
Provide links to more background information.
